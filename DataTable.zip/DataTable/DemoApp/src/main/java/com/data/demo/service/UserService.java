package com.data.demo.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.data.demo.model.User;

public interface UserService {

	public List<User> getAllUsers();
	
	public Optional<User> getUserById(int userId);
	
	public User createUser(User user);
	
}
