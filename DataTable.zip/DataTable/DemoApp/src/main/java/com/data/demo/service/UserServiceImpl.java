package com.data.demo.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.data.demo.model.User;
import com.data.demo.repository.UserRepository;

@Component
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public List<User> getAllUsers() {
		List<User> list = (List<User>)this.userRepository.findAll();
		return list;
	}

	@Override
	public Optional<User> getUserById(int userId) {
		Optional<User> user = null;
		try {	
			user = this.userRepository.findById(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public User createUser(User u) {
		User user = this.userRepository.save(u);
		return user;
	}

}
